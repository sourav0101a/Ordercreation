/**
 * @description       : Checkout Page
 * @author            : Poojitha Anthati
 * @group             : Capgemini
 * @last modified on  : 05-16-2022
 * @last modified by  : Poojitha Anthati
 **/

import {
    LightningElement,
    api,
    track
} from 'lwc';
import {
    NavigationMixin
} from 'lightning/navigation';
import {
    ShowToastEvent
} from 'lightning/platformShowToastEvent';

//Apex Classes
import getUserAccounts from '@salesforce/apex/BDT_B2B_CheckoutController.getUserAccounts';
import getShipToAccounts from '@salesforce/apex/BDT_B2B_CheckoutController.getShipToAccounts';
import UpdateCart from '@salesforce/apex/BDT_B2B_CheckoutController.UpdateCart';
import getCartFields from '@salesforce/apex/BDT_B2B_CheckoutController.getCartFields';
import getSFOrderNo from '@salesforce/apex/BDT_B2B_CheckoutController.getSFOrderNo';
import getSapOrderNo from '@salesforce/apex/BDT_B2B_CheckoutController.getSapOrderNo';
import getOrderFields from '@salesforce/apex/BDT_B2B_CheckoutController.getOrderFields';
import getFreightTermList from '@salesforce/apex/BDT_B2B_CheckoutController.getFreightTermList';
import freightCarrier from '@salesforce/apex/BDT_B2B_CheckoutController.freightCarrier';

// Custom label
import BDT_B2B_TermsAndConditions from '@salesforce/label/c.BDT_B2B_TermsAndConditions';


export default class BdtB2BCheckoutPage extends NavigationMixin(LightningElement) {

    /**
     * The effectiveAccountId provided by the checkout first page.
     *
     * @type {string}
     */
    @api effectiveAccountId;

    /**
     * The recordId provided by the checkout first page.
     *
     * @type {string}
     */
    @api recordId;

    /**
     * ID of the cart
     * 
     * @type {string}
     */
    cartId;

    /**
     * Key value pairs for the dropdown list
     * 
     * @property {shippingAddress[]} 
     */
    shippingAddress = [];

    /**
     * Information of the User Account
     * 
     * @property {accoutnInfo[]}  
     */
    accountInfo;

    /**
     * Account Name of the user
     * 
     * @property {string}  
     */
    accountName;

    /**
     * Account Number of the user
     * 
     * @property {string} 
     */
    accountNumber;

    /**
     * Checks whether the page is checkout first page or second page
     * 
     * @property {boolean} 
     */
    @track isCheckout2 = false;

    /**
     * Checks whether the PO Number is entered or not
     * 
     * @property {boolean} 
     */
    @track isFilled = false;

    /**
     * Validate if the checkbox of Accept Terms and Condition is checked
     * 
     * @property {boolean} 
     */
    @track checked = false;

    /**
     * Check to enable/disable Submit Payment button
     * 
     * @property {boolean} 
     */
    @track stopPayment = false;

    /**
     * To show/hide lightning Spinner
     * 
     * @property {boolean} 
     */
    @track isLoader;

    /**
     * stores the current page url
     * 
     * @property {string} 
     */
    pathName;

    /**
     * Billing Street of User Account
     * 
     * @property {string} 
     */
    billingStreet;

    /**
     * Billing City of User Account
     * 
     * @property {string} 
     */
    billingCity;

    /**
     * Billing State of User Account
     * 
     * @property {string} 
     */
    billingState;

    /**
     * Billing Postal of User Account
     * 
     * @property {string} 
     */
    billingZipCode;

    /**
     * Billing Country of User Account
     * 
     * @property {string} 
     */
    billingCountry;

    /**
     * Stores the user selected Shipping Address
     * 
     * @property {string} 
     */
    selectedOption;

    /**
     * Sends the user selected Shipping Address to local Storage
     * 
     * @property {string} 
     */
    selectedValue;

    /**
     * Gets the user selected Shipping Address from local storage
     * 
     * @property {string} 
     */
    selectedShipTo;

    /**
     * Account number of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingAccNum;

    /**
     * Shipping Street of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingStreet;

    /**
     * Shipping City of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingCity;

    /**
     * Shipping State of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingState;

    /**
     * Shipping PostalCode of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingZipCode;

    /**
     * Shipping Country of the user selected Ship To Account
     * 
     * @property {string} 
     */
    shippingCountry;

    /**
     * Stores the order Instruction entered by User
     * 
     * @property {string} 
     */
    orderInstructions;

    /**
     * Stores the PO Number entered by User
     * 
     * @property {string} 
     */
    poNumber;

    /**
     * Subtotal amount of the ordered items
     * 
     * @property {Currency} 
     */
    subTotal;

    /**
     * Estimated Tax for the ordered items
     * 
     * @property {Currency} 
     */
    tax;

    /**
     * Total amount of the ordered items
     * 
     * @property {Currency} 
     */
    total;

    /**
     * Terms and Conditions document
     * 
     * @property {Document} 
     */
    doc;

    /**
     * Salesforce generated order Number
     * 
     * @property {string} 
     */
    orderNumber;

    /**
     * Salesforce generated order Summary Id
     * 
     * @property {string} 
     */
    orderSummaryId;

    /**
     * Salesforce generated order Id
     * 
     * @property {string} 
     */
    orderId;

    /**
     * Pattern of PO Number
     * 
     * @property {string} 
     */
    pattern;

    /**
     * checks whether the Po Number matches the pattern
     * 
     * @property {boolean} 
     */
    @track isPattern = false;

    /**
     * checks whether the cart amount is greater than 5000
     * 
     * @property {boolean} 
     */
    @track is_small_cart = false;

    /**
    * checks whether the Freight Terms is 'COL'
    * 
    * @property {boolean} 
    */
    @track isFreightCollect = false;

    /**
     * @property {String []}
     */
    freight_terms = null;

    /**
     * 
     * @property {string} 
     */
    @track selectedFreight;

    /**
     * 
     * @property {string []} 
     */
    carrierListOptions

    /**
      * 
      * @property {string} 
      */
    selectedCarrier

    /**
     * 
     * @property {string} 
     */
    displayFreight;

    /**
     * 
     * @property {string} 
     */
    displayCarrier;

    /**
     * 
     * @property {string} 
     */
    displayCarrierAcNo;

    /**
     * Pattern of Carrier Account Number
     * 
     * @property {string} 
     */
     acntNumPattern;

     /**
      * checks whether the Carrier Account Number is empty
      * 
      * @property {boolean} 
      */
     @track isEmpty = true;

    //Custom labels
    label = {
        BDT_B2B_TermsAndConditions
    }

    /*Invokes as soon as the page is loaded */
    connectedCallback() {
        this.isLoader = true;
        this.displayFreight = this.selectedFreight = localStorage.getItem('freightTerm');
        this.displayCarrier = this.selectedCarrier = localStorage.getItem('carrierPartner');
        this.displayCarrierAcNo = this.carrierAccountNo = localStorage.getItem('carrierAccount');
        this.isEmpty = (this.carrierAccountNo != null && this.carrierAccountNo != undefined) ? false : true;
        this.cartId = localStorage.getItem('cartId');
        this.selectedShipTo = localStorage.getItem('selectedAddress');
        this.selectedValue = (this.selectedShipTo != undefined) ? this.selectedShipTo : undefined;
        this.getAccount();
        this.getShippingAddress();
        this.getfreightCarrier();
        this.stopPayment = true;

        //Checking the page url to show the template accordingly
        var pathname = new URL(window.location.href).pathname.split('/s/');
        this.pathName = pathname[1];
        if (this.pathName === 'checkout2') {
            this.isCheckout2 = true;
        }

        this.doc = this.label.BDT_B2B_TermsAndConditions;

        this.freightTermList();
    }

    freightTermList() {
        getFreightTermList()
            .then((result) => {
                let terms = [];
                for (var ft in result) {
                    terms.push({ label: ft, value: result[ft] });
                }

                this.freight_terms = terms;
                this.isFreightCollect = (this.selectedFreight == "COL");
            })
            .catch((error) => {
                console.log("Error:", error);
            })
    }


    /* Get the account of the user */
    getAccount() {
        getUserAccounts({
            accId: this.effectiveAccountId
        })
            .then(result => {
                if (result.length != 0) {
                    this.accountInfo = result[0];
                    this.accountName = this.accountInfo.Name != null ? this.accountInfo.Name : '';
                    this.accountNumber = this.accountInfo.BDT_CPQ_SAP_Customer_Number__c != null ? this.accountInfo.BDT_CPQ_SAP_Customer_Number__c : '';
                    this.billingStreet = this.accountInfo.BillingStreet != null ? this.accountInfo.BillingStreet : '';
                    this.billingCity = this.accountInfo.BillingCity != null ? this.accountInfo.BillingCity + ',' : '';
                    this.billingState = this.accountInfo.BillingState != null ? this.accountInfo.BillingState : '';
                    this.billingZipCode = this.accountInfo.BillingPostalCode != null ? this.accountInfo.BillingPostalCode : '';
                    this.billingCountry = this.accountInfo.BillingCountry != null ? this.accountInfo.BillingCountry : '';
                }
                this.getChildAccount();
            })
            .catch((error) => {
                console.log("Error:", error);
            })
    }

    /* Get Ship To accounts of the user account */
    getChildAccount() {
        getShipToAccounts({
            parentId: this.effectiveAccountId
        })
            .then((result) => {
                let options = [];
                for (let i = 0; i < result.length; i++) {
                    let address = (result[i].BillingStreet != null ? result[i].BillingStreet + ', ' : '') +
                        (result[i].BillingCity != null ? result[i].BillingCity + ' ' : '') +
                        (result[i].BillingState != null ? result[i].BillingState : '') +
                        (result[i].BillingPostalCode != null ? ', ' + result[i].BillingPostalCode : '')

                    options.push({
                        label: address,
                        value: result[i].Id + '|' +
                            result[i].BDT_CPQ_SAP_Customer_Number__c + '|' +
                            result[i].BillingStreet + '|' +
                            result[i].BillingCity + '|' +
                            result[i].BillingState + '|' +
                            result[i].BillingPostalCode + '|' +
                            result[i].BillingCountry,
                        freight: ((result[i].BDT_CPQ_Freight_Terms__c == undefined ||
                            result[i].BDT_CPQ_Freight_Terms__c == 'PPD') ?
                            null : result[i].BDT_CPQ_Freight_Terms__c)
                    });
                }
                this.shippingAddress = options;

                setTimeout(() => {
                    this.getCartData();
                }, 1000);
            })
            .catch((error) => {
                console.log("Error:", error);
            })
    }

    /* Get the fields of webcart */
    getCartData() {
        getCartFields({
            webcartId: this.cartId
        })
            .then((result) => {
                this.isLoader = false;
                this.orderInstructions = result.length != 0 ? result[0].BDT_B2B_Order_Instructions__c : '';
                this.tax = result.length != 0 ? result[0].BDT_B2B_Estimated_Tax__c : 0;
                if (this.tax === undefined) {
                    this.tax = 0;
                }
                this.total = result.length != 0 ? result[0].TotalAmount + (this.tax == undefined || this.tax == null ? 0 : this.tax) : 0;
                if (this.total === undefined) {
                    this.total = 0;
                }

                this.subTotal = result.length != 0 ? result[0].TotalAmount : 0;
                this.poNumber = result.length != 0 ? result[0].PoNumber : undefined;
                if (this.poNumber != undefined && this.poNumber != null) {
                    this.isFilled = true;
                } else {
                    this.isFilled = false;
                }
            })
            .catch((error) => {
                console.log("Error:", error);
            })
    }

    /* Get the Ship To address options */
    get options() {
        return this.shippingAddress;
    }

    /* Stores the user selected Shipping Address */
    /* Changes the value of Freight to the default connected with the account */
    handleShippingAddress(event) {
        this.selectedValue = this.selectedOption = this.selectedShipTo = event.detail.value;

        //Freight should not change away from PPD for big carts
        if (!this.bigCart) {
            for (var val of this.shippingAddress) {
                if (val.value == event.detail.value) {
                    this.selectedFreight = val.freight;
                    this.isFreightCollect = (this.selectedFreight == "COL");
                    break;
                }
            }

            localStorage.setItem('freightTerm', this.selectedFreight);
        }

        localStorage.setItem('selectedAddress', this.selectedOption);
        this.getShippingAddress();
    }

    handleFreightChange(event) {
        this.selectedFreight = event.detail.value;
        this.isFreightCollect = (this.selectedFreight == "COL");
        localStorage.setItem('freightTerm', this.selectedFreight);
    }

    /*Returns true if the Cart TotalValue is over $5000
    // Also sets the selectedFreight and doesn't allow it to be changed

    //Returns false if the Cart Totalvalue is under $5000
    // Also creates a list of freight terms for the user to choose from */
    get bigCart() {
        //Carts over $5000 have their freight preset to "PPD"
        if (this.total >= 5000) {
            this.selectedFreight = "PPD";
            localStorage.setItem('freightTerm', this.selectedFreight);
            return true;
        }
        //A freight selection of "PPD" is not allowed when Cart Value >= $5000

        else {
            //Remove PPD from the available Freight Terms list
            if (this.freight_terms && this.freight_terms != null) {
                this.freight_terms = this.freight_terms.filter(ft => ft.value != 'PPD');
            }
            return false;
        }
    }

    /* Stores the user entered order Instructions */
    handleOrderInstructions(event) {
        this.orderInstructions = event.target.value;
    }

    /* Stores the user entered Po Number */
    handlePoNumber(event) {
        this.poNumber = event.target.value.trim();

        //pattern that do not the accept space as first character
        this.pattern = /^\S.*$/;
        this.isPattern = this.pattern.test(this.poNumber);

        //Validate PoNumber is not null and following the pattern
        if (this.poNumber.length != 0 && this.poNumber != undefined &&
            this.poNumber != null && this.isPattern == true) {
            this.isFilled = true;
        } else {
            this.isFilled = false;
        }
        this.enableSubmit();
    }

    /* Handles the checkbox of terms ans conditions */
    handleCheckbox(event) {
        this.checked = event.target.checked;
        this.enableSubmit();
    }

    /* Enable or Disable submit payment based on conditions */
    enableSubmit() {
        if (this.checked == true && this.isFilled == true) {
            this.stopPayment = false;
        } else {
            this.stopPayment = true;
        }
    }

    /* Navigates to the previous page*/
    handlePrevious() {
        this.updateWebcart();
        let url;
        let newUrl;
        if (this.isCheckout2 == true) {
            url = window.location.href.split('/s/');
            newUrl = url[0] + '/s/checkout/' + this.cartId;
        } else {
            url = window.location.href;
            newUrl = url.replace(/checkout/, 'cart');
        }
        this.navigateToWebPage(newUrl);
    }

    /* Navigates to the Next page*/
    handleNext() {
        let url = window.location.href.split('/s/');
        let isThereError = false;
        let isValidSelections = false;
        let toastMessage = { title: 'Error', message: ' is required.', variant: 'error', mode: 'dismissable' };

        if (this.isCheckout2 == true) {
            if (this.stopPayment == false) {
                this.isLoader = true;

                //Update webcart with latest Po number and order Instrcutions before placing order
                UpdateCart({
                    cartId: this.cartId,
                    poNumber: this.poNumber,
                    instructions: this.orderInstructions
                })
                    .then(() => {
                        //Place the order and get Salesforce generated order Number
                        getSFOrderNo({
                            cartId: this.cartId,
                            shipToAccId: this.selectedShipTo[0],
                            freightTerm: this.displayFreight,
                            carrierPartner: this.displayCarrier,
                            carrierAccountNo: this.displayCarrierAcNo
                        })
                            .then((result) => {
                                if (result.isSuccess == true) {
                                    this.orderNumber = result.data.orderNumber;
                                    this.orderSummaryId = result.data.orderSummaryId;
                                    this.getOrderId();
                                }
                                else {
                                    this.isLoader = false;
                                    url = url[0] + '/s/cart/' + this.cartId;
                                    this.navigateToWebPage(url);

                                    this.dispatchEvent(
                                        new ShowToastEvent({
                                            title: 'Oops!',
                                            message: 'Order Creation Failed',
                                            variant: 'error',
                                            mode: 'dismissable'
                                        })
                                    );
                                }
                            })
                            .catch((error) => {
                                console.log("Error in getSFOrderNo:", error);
                            })
                    })
            }

        }
        //Valid Ship-to Account?
        else if (this.selectedValue != undefined && this.selectedValue != null) {
            //Ship-to Selected
            //Valid Freight?
            if (this.selectedFreight != undefined && this.selectedFreight != null) {
                //Freight Selected
                //Is Freight Collect?
                if (this.isFreightCollect) {
                    //Freight = Collect
                    //Is Carrier Selected?
                    if (this.selectedCarrier != undefined && this.selectedCarrier != null) {
                        //Carrier Selected
                        //Is Account Filled out?
                        if (this.carrierAccountNo != undefined && this.carrierAccountNo != null && this.isEmpty == false) {
                            //Everything filled out properly
                            isValidSelections = true;
                        }
                        //Carrier Account Not Filled
                        else {
                            isThereError = toastMessage.message = 'Carrier Account' + toastMessage.message;
                        }
                    }
                    //No Carrier Selected
                    else {
                        isThereError = toastMessage.message = 'Carrier selection' + toastMessage.message;
                    }
                }
                //Freight is NOT collect
                else {
                    //Everything filled out properly
                    isValidSelections = true;
                }
            }
            //No Freight Selection
            else {
                isThereError = toastMessage.message = 'Freight selection' + toastMessage.message;
            }

        }
        //No Ship-to Selected
        else {
            isThereError = toastMessage.message = 'ShipTo Address' + toastMessage.message;
        }

        if(isValidSelections){
            //Valid selections. Proceed to checkout2
            this.updateWebcart();
            url = url[0] + '/s/checkout2';
            this.navigateToWebPage(url);
        }else if (isThereError) {
            //Something is not filled out properly. Show error to user
            this.dispatchEvent(new ShowToastEvent(toastMessage));
        }
    }
    /* Navigates to a web page*/
    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url
            }
        });
    }

    /* Update webcart while navigating between pages*/
    updateWebcart() {
        UpdateCart({
            cartId: this.cartId,
            poNumber: this.poNumber,
            instructions: this.orderInstructions,
        })
            .then((result) => {
                this.orderInstructions = result[0].BDT_B2B_Order_Instructions__c;
                this.poNumber = result[0].PoNumber;
            })
    }

    /* Get user selected shipping address to display on checkout second page*/
    getShippingAddress() {
        if (this.selectedShipTo != undefined) {
            this.selectedShipTo = this.selectedShipTo.split('|');
            this.shippingAccNum = this.selectedShipTo[1] != 'undefined' ? this.selectedShipTo[1] : '';
            this.shippingStreet = this.selectedShipTo[2] != 'undefined' ? this.selectedShipTo[2] : '';
            this.shippingCity = this.selectedShipTo[3] != 'undefined' ? this.selectedShipTo[3] + ',' : '';
            this.shippingState = this.selectedShipTo[4] != 'undefined' ? this.selectedShipTo[4] : '';
            this.shippingZipCode = this.selectedShipTo[5] != 'undefined' ? this.selectedShipTo[5] : '';
            this.shippingCountry = this.selectedShipTo[6] != 'undefined' ? this.selectedShipTo[6] : '';
        }
    }

    /* Get the SF Order Id to perform order Simulate*/
    getOrderId() {
        getOrderFields({
            orderNo: this.orderNumber
        })
            .then((result) => {
                console.log("Updated Order Obj:", result);
                this.orderId = result[0].Id;
                this.orderSimulate();
            })
            .catch((error) => {
                console.log("Error in Order : ", error);
            })
    }

    /* Simulate the salesforce order to SAP order*/
    orderSimulate() {
        getSapOrderNo({
            OrderId: this.orderId
        })
            .then((result) => {
                this.getUrl();
                this.isLoader = false;
                localStorage.removeItem('selectedAddress');
                //remove carrier info from local storage
                localStorage.removeItem('freightTerm');
                localStorage.removeItem('carrierPartner');
                localStorage.removeItem('carrierAccount');
            })
            .catch((error) => {
                console.log("Error in order Simulate: ", error);
            })
    }

    /* get url of the order confirmation page*/
    getUrl() {
        let url = window.location.href.split('/s/');
        let newUrl;
        newUrl = url[0] + '/s/orderconfirmation/' + this.orderId;
        this.navigateToWebPage(newUrl);
    }

    /*Get list of carrier names */
    getfreightCarrier() {
        freightCarrier()
            .then((result) => {
                console.log("Carrier List : ", result);
                let options = [];
                for (let i = 0; i < result.length; i++) {
                    options.push({
                        label: result[i].Name,
                        value: result[i].Vendor
                    });
                }
                this.carrierListOptions = options;
            })
            .catch((error) => {
                console.log('Error in getting CarrierList :', error);
            })
    }

    handleCarrierChange(event) {
        this.selectedCarrier = event.detail.value;
        localStorage.setItem('carrierPartner', this.selectedCarrier);
    }

    handleAccountNum(event) {
        this.carrierAccountNo = event.target.value.trim();
        localStorage.setItem('carrierAccount', this.carrierAccountNo);
        
        //pattern that do not the accept only space as input
        this.acntNumPattern = /^\s*$/;
        this.isEmpty = this.acntNumPattern.test(this.carrierAccountNo);
    }
}