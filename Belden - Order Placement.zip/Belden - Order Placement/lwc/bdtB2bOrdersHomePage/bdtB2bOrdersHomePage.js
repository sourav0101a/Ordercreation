import { LightningElement,track,api,wire } from 'lwc';
import {    NavigationMixin } from 'lightning/navigation';
import { ShowToastEvent } from 'lightning/platformShowToastEvent';
import getOrderList from "@salesforce/apex/BDT_B2B_CallEnosix.getOrderList";
import getUserAccounts from "@salesforce/apex/BDT_B2B_CallEnosix.getUserAccounts";
import searchAccount from "@salesforce/apex/BDT_B2B_CallEnosix.getUserAccounts";
import USER_ID from "@salesforce/user/Id";
import getOrderPageSize from "@salesforce/apex/BDT_B2B_QuoteListViewsController.getOrderPageSize";

export default class BdtB2bOrdersHomePage extends NavigationMixin(LightningElement) {

    @track value;
    clickedButtonLabel;
    @track soldToValue;
    @track hide;
    @api shippingConditionValue;
    @api createDate;
    @api lastDate;
    @api dateError;
    @api arrayLength;
    @api orderNumber;
    @api effectiveAccountId;
    customFormModal = false;
    show = false;
    soldTo;
    userClicked;
    PONumber;
    invoice;
    SalesOrderNo;
    orders;
    dataa;
    visibleAccounts;
    erpCustomerNumber;

    recordsperPage;
    totalPages = 1;
    pageNo;
    totalRecords;
    recordsToDisplay;
    disableNextBtn = true;
    disablePreviousBtn = true;

    // isLoader = false;
    // @api StatusSD;
    // @api orderId;
    // @api recordId;
    // shipTo;
    // sku;
    // pageLength = 15;
    // page = 1;
    @track SelectOther = false;



    connectedCallback() {
        this.OrderPageSize();
        this.getAccountOptions();
        this.createDate = new Date();
        this.createDate.setDate(this.createDate.getDate() - 90);
        this.createDate = this.createDate.toISOString().slice(0, 10);
        this.lastDate = new Date();
        // this.lastDate.setDate(this.lastDate.getDate() + 30); // add 30 days 
        this.lastDate = this.lastDate.toISOString().slice(0, 10);
    }
   
    getAccountOptions(){
        getUserAccounts({ accid : this.effectiveAccountId })
        .then((result) => {
            let res = JSON.stringify(result[0].BDT_CPQ_SAP_Customer_Number__c);
                this.erpCustomerNumber = JSON.parse(res);
            this.value = this.erpCustomerNumber;   
            this.soldToValue = this.erpCustomerNumber;   
        })
        .catch((error) => {
            this.errorMsg = error;
        });
       }

    get shippingCondition1() {
        return [{ label: (this.erpCustomerNumber), value: (this.erpCustomerNumber)},
            ];
    }


    handleSoldTo(event) {
        this.soldToValue = event.target.value;
        console.log('Selected SoldToValue:', this.soldToValue);
    }

    /*get shippingCondition() {
        return [{ label: ('All'), value: 'All'},
                { label: ('Cancelled'),value: 'Cancelled'},
                { label: ('Invoiced') ,value: 'Invoiced'},
                { label: ('Open'), value: 'Open' },
                { label: ('Picked'),value: 'Picked' },
                { label: ('Saved') ,value: 'Saved'},
                { label: ('Shipped'), value: 'Completed' },
            ];
    }*/
    get shippingCondition() {
        return [{ label: ('All'), value: 'All'},
                { label: ('Open'), value: 'Open' },
                { label: ('Completed'), value: 'Completed' },
            ];
    }

    clickShiped(event) {
        this.userClicked = event.target.value;
        this.SelectOther = false;
        // if(this.userClicked == 'Cancelled' || this.userClicked == 'Invoiced' || 
        // this.userClicked == 'Picked' || this.userClicked == 'Saved'){
        //     const event = new ShowToastEvent({
        //         title: 'Error Message',
        //         message: 'No Data found for this status',
        //         variant: 'error',
        //         mode: 'dismissable'
        //     });
        //     this.dispatchEvent(event);
        //     this.orders = [];
        //     this.SelectOther = true;
        // }
        // console.log("User clicked :", this.userClicked)
    }

    handleCreateChange(event) {
        this.createDate = event.target.value;
        console.log("create date : " + this.createDate);
        this.dateError = false;
    }

    handleLastChange(event) {
        this.lastDate = event.target.value;
        console.log("last date : ", this.lastDate);
        this.dateError = false;
    }

    get todaysDate() {
        var today = new Date(this.createDate);
        today.setDate(today.getDate() + 120);
        today = today.toISOString().slice(0, 10);
        console.log("To Date" + today);
        return today;
    }

    get FormatDate() {
        console.log("KYLE : dateRec" + this.createDate);
        dateRe = new Date();
        dateRe.setFullYear(this.createDate.slice(0, 4));
        dateRe.setDate(this.createDate.slice(6, 7));
        dateRe.setMonth(this.createDate.slice(9, 10));
        console.log("KYLE : date" + dateRe);
        return new Intl.DateTimeFormat(LOCALE).format(dateRe);
    }

    handlePONo(event) {
        this.PONumber = event.target.value;
        console.log("po number : ", this.PONumber)
    }

    handleInvoice(event) {
        this.invoice = event.target.value;
        console.log("po number : ", this.invoice)
    }

    handleSalesOrderNo(event) {
        this.SalesOrderNo = event.target.value;
        console.log("sales orderv no: ", this.SalesOrderNo)
    }

    
    
    setValuesOnPageLoad(){        
        this.totalRecords = this.orders.length;
        if(this.totalRecords > this.recordsperPage){
            this.disableNextBtn = false;
        }
        this.pageNo = 1;
        this.totalPages = Math.ceil(this.orders.length / this.recordsperPage );
        if(this.totalPages == 0){
            this.totalPages = 1
        }
        if(this.totalRecords <= this.recordsperPage){
            this.disableNextBtn = true;
            this.disablePreviousBtn = true;
        }
        if(this.pageNo == 1){
            this.disablePreviousBtn = true;
        }
        this.preparePaginationList();
    }
    preparePaginationList(){
        let begin = (this.pageNo - 1) * parseInt(this.recordsperPage);
        let end = parseInt(begin) + parseInt(this.recordsperPage);
        this.recordsToDisplay = this.orders.slice(begin, end);                
    }
    handleNext() {
        this.pageNo += 1;
        if(this.totalPages == this.pageNo){
            this.disableNextBtn = true;
        }
        this.disablePreviousBtn = false;
        this.preparePaginationList();
    }
    handlePrevious() {
        this.pageNo -= 1;
        if(this.pageNo == 1){
            this.disablePreviousBtn = true;
        }
        this.disableNextBtn = false;        
        this.preparePaginationList();
    }
    handleClick(event) {
        let label = event.target.label;
        if (label === "Previous") {
            this.handlePrevious();
        } else if (label === "Next") {
            this.handleNext();
        } 
    }

    OrderList() {
        var date1 = new Date(this.createDate);
        var date2 = new Date(this.lastDate);
        var timeDiffrence = Math.abs(date2.getTime() - date1.getTime());
        var differDays = Math.ceil(timeDiffrence / (1000 * 3600 * 24));
        console.log("Difference between dates :", differDays);

        console.log("Sold To Value :" + this.soldToValue);

        if (this.soldToValue != undefined) {
            getOrderList({
                salesOrderNo: this.SalesOrderNo,
                poNumber: this.PONumber,
                createDate: this.createDate,
                lastDate: this.lastDate,
                soldTo: this.soldToValue,
                userClicked: this.userClicked,
                userId: ""
            })   
            .then((result) => {
                console.log("Result: ", result);
                this.orders = result;
                this.setValuesOnPageLoad();
                console.log("userClicked"+ this.userClicked);
                if(this.userClicked == 'Cancelled' || this.userClicked == 'Invoiced' || 
                this.userClicked == 'Picked' || this.userClicked == 'Saved'){
                    const event = new ShowToastEvent({
                        title: 'Error Message',
                        message: 'No Data found for this status',
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(event);
                    this.orders = [];
                    this.recordsToDisplay = [];
                    this.SelectOther = true;
                }else
                if ((this.orders.length) <= 0) {
                    this.customFormModal = false;
                    const event = new ShowToastEvent({
                        title: 'Error Message',
                        message: 'No Orders in the History for these details',
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(event);
                }
                else {
                    this.customFormModal = true;
                }          
            })
            .catch((error) => {
                if (error.body.message.includes('ACCESS_EXCEPTION')) {
                    const event = new ShowToastEvent({
                        title: 'Error Message',
                        message: 'No Orders in the History for these details',
                        variant: 'error',
                        mode: 'dismissable'
                    });
                    this.dispatchEvent(event);
                }
                console.log("error:", error)
            })  
        } else {
            // this.isLoader = false;
            this.dispatchEvent(
                new ShowToastEvent({
                    title: 'Error',
                    message: 'Please fill the mandatory fields',
                    variant: 'error',
                    mode: 'dismissable'
                })
            );
        }
    }
   
    handleNavigate(event) {
        this.orderNumber = event.currentTarget.dataset.value;
        //this.orderId = '1Os7h00000000jfCAA';
        // event.currentTarget.dataset.value;
        let url = window.location.origin + window.location.pathname;
        console.log("new url : ", url)
        let newUrl = url.replace('/orderhistory', '/order-detail')
        console.log("url123", newUrl)
        this.navigateToWebPage(newUrl);
    }

    navigateToWebPage(url) {
        this[NavigationMixin.Navigate]({
            type: 'standard__webPage',
            attributes: {
                url: url + '?orderNumber=' + this.orderNumber
            }
        });
    }
    
    
    get ArrayLength() {
        console.log("Dataa length:", this.dataa.length);
        if (this.dataa.length === 0) {
            setTimeout(() => {
                this.hide = true;
            }, 500);
        } else {
            this.hide = false;
        }
        return this.hide;
    }

    OrderPageSize() {
        getOrderPageSize()
            .then((pagesize) => {
                if(pagesize !=null){
                    this.recordsperPage = pagesize;
                }else{
                    this.recordsperPage = 20;
                }
            })
            .catch((e) => {
                console.log(e);
            });
    }

    // handleAccrdionTable(event) {
    //     console.log('Click Icon', event);
    //     let accordionBtns = this.template.querySelectorAll(".accordion");
    //     accordionBtns.forEach((item) => {
    //         item.addEventListener('click', () => {

    //                 item.parentElement.parentElement.classList.contains('is-open') ?
    //                 item.parentElement.parentElement.classList.remove('is-open') :
    //                 item.parentElement.parentElement.classList.add('is-open');
    //         });
    //     });
    // }
}