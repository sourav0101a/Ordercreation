import { LightningElement, api, wire, track } from 'lwc';
import { NavigationMixin, CurrentPageReference } from 'lightning/navigation';
import getOrderDetail from "@salesforce/apex/BDT_B2B_CallEnosix.getOrderDetail";

export default class BdtB2BOrderDetail extends NavigationMixin(LightningElement) {
    @track isLoader = false;
    @api sapOrderNumber;
    @api currencyCode;
    orderedDate;
    orderdedTime;
    poNumber;
    accountName;
    accountNumber;
    ownerName;
    orderStatus;
    billToStreet;
    billToCity;
    billToState;
    billToCountry;
    billToPostalCode;
    billToCountryName;
    shipToStreet;
    shipToCity;
    shipToState;
    shipToCountry;
    shipToPostalCode;
    shipToCountryName;
    shipToCarrier;
    shipToPartnerName;
    total = 0;
    subTotal = 0;
    tax = 0;
    @track mapObj = [];
    items;
    
    /**
     * An object with the current PageReference.
     * This is needed for the pubsub library.
     *
     * @type {PageReference}
     */
    @wire(CurrentPageReference)
    pageRef;


    @wire(CurrentPageReference)
    getStateParameters(currentPageReference) {
        if (currentPageReference) {
            console.log('SapOrderNumber: ', currentPageReference.state.orderNumber);
            this.sapOrderNumber = currentPageReference.state.orderNumber;
        }
    }

    connectedCallback() {
        this.isLoader = true;
        this.orderDetails();
    }
    get PartnerName (){
        if(this.shipToCarrier == 'Carrier'){
            return this.shipToPartnerName;
        }else{
            return '';
        }
    }

    // To hide/show the carrier information on order details
    get hideCarrier(){
        if(this.shipToCarrier == 'Carrier'){
            return true;
        }else{
            return false;
        }
    }

    orderDetails() {
        getOrderDetail({
            sapNumber: this.sapOrderNumber
        })
        .then((result)=>{
            console.log('Order Details: ', result);
            this.isLoader = false;
            if(result.length != 0){
                this.items = result[0];
                this.orderedDate = this.items.orderDate.CreateDate;
                this.orderedTime = this.items.orderDate.EntryTime;
                this.poNumber = this.items.salesDocument.CustomerPurchaseOrderNumber;
                this.accountName = this.items.orderSoldTo.PartnerName;
                this.accountNumber = this.items.orderSoldTo.PartnerNumber;
                this.ownerName = this.items.orderDate.CreatedBy;
                this.orderStatus = this.items.orderStatus.DeliveryStatusDescription;
                this.billToStreet = this.items.orderSoldTo.Street;
                this.billToCity = this.items.orderSoldTo.City;
                this.billToState = this.items.orderSoldTo.Region;
                this.billToCountry = this.items.orderSoldTo.Country;
                this.billToPostalCode = this.items.orderSoldTo.PostalCode;
                this.billToCountryName = this.items.orderSoldTo.CountryName;
                this.shipToStreet = this.items.orderShipTo.Street;
                this.shipToCity = this.items.orderShipTo.City;
                this.shipToState = this.items.orderShipTo.Region;
                this.shipToCountry = this.items.orderShipTo.Country;
                this.shipToPostalCode = this.items.orderShipTo.PostalCode;
                this.shipToCountryName = this.items.orderShipTo.CountryName;

                let itemSchedules = this.items.orderItemsSchedule;
                let itemsUserDefinedFields = this.items.orderItemsUserDefined;
                let orderItems = this.items.orderItems;
                let lineNumber = 1;
                for(let orderItem of orderItems) {
                    if (!orderItem.Material) {
                        continue;
                    }
                    let itemSchedule = itemSchedules.find(obj => obj.SalesItem === orderItem.SalesItem);
                    let pricePerUnit = orderItem.NetItemPrice;
                    let itemStatus = '';
                    
                    if (typeof itemsUserDefinedFields !== 'undefined') {
                        let itemsUserDefinedField = itemsUserDefinedFields.find(obj => obj.SalesItem === orderItem.SalesItem);
                        itemStatus = itemsUserDefinedField.VALUE;
                    }

                    //Handle condition pricing unit so that PSP price is always per unit
                    if (parseInt(orderItem.ConditionPricingUnit) > 1) {
                        pricePerUnit = orderItem.NetItemPrice / orderItem.ConditionPricingUnit ;
                    }

                    let obj = {
                        line : lineNumber,
                        partNumber : orderItem.Material,
                        status : itemStatus,
                        custDate : this.items.orderDate.RequestedDeliveryDate,
                        lineDate : orderItem.ScheduleLineDate,
                        extPrice : orderItem.NetValueInDocumentCurrency,
                        pricePerUnit: pricePerUnit,
                        uom : orderItem.SalesUnit,
                        commitDate : itemSchedule.ScheduleLineDate,
                        orderedQty : itemSchedule.OrderQuantity,
                        taxAmount: orderItem.ItemTax
                    };
                    this.mapObj.push(obj);
                    this.currencyCode = orderItem.SDDocumentCurrency; 
                    lineNumber++;
                }
                this.tax = parseFloat(this.items.salesDocument.TaxAmountInDocumentCurrency).toFixed(2);
                this.subTotal = parseFloat(this.items.salesDocument.NetValueInDocumentCurrency).toFixed(2);
                this.total = parseFloat(this.subTotal) + parseFloat(this.tax);
                this.shipToCarrier = this.items.carrier.PartnerFunctionName;
                this.shipToPartnerName = this.items.carrier.PartnerName;
            }
        })
        .catch((error)=>{
            console.log('Error in orderDetails: ', error);
        })
    }
}